package com.farmcontroller.service;

import com.farmcontroller.dto.FarmReportDTO;
import com.farmcontroller.dto.FieldReportDTO;
import com.farmcontroller.dto.SeasonReportDTO;
import com.farmcontroller.models.Farm;
import com.farmcontroller.models.Field;
import com.farmcontroller.models.Harvested;
import com.farmcontroller.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    private FarmRepository farmRepository;

    @Autowired
    private HarvestedRepository harvestedRepository;

    @Override
    public List<FarmReportDTO> generateFarmReports() {
        List<Farm> farms = farmRepository.findAll();
        List<FarmReportDTO> farmReports = new ArrayList<>();

        for (Farm farm : farms) {
            FarmReportDTO farmReport = new FarmReportDTO();
            farmReport.setFarmId(farm.getId());
            farmReport.setFarmName(farm.getName());

            List<SeasonReportDTO> seasonReports = new ArrayList<>();

            // Fetch planted and harvested data for the farm
            List<Field> fields = farm.getFields();
            for (Field field : fields) {
                SeasonReportDTO seasonReport = new SeasonReportDTO();
                seasonReport.setSeason(field.getSeason());
                seasonReport.setPlantedAreaAcres(field.getPlantingAreaAcres());


                Harvested harvested = harvestedRepository.findByFieldIdAndSeason(field.getId(), field.getSeason());
                if (harvested != null) {
                    seasonReport.setActualHarvestedTons(harvested.getActualHarvestedTons());
                } else {
                    seasonReport.setActualHarvestedTons(0.0); // Or handle null case as needed
                }

                seasonReports.add(seasonReport);
            }

            farmReport.setSeasons(seasonReports);
            farmReports.add(farmReport);
        }

        return farmReports;
    }

    public List<FarmReportDTO> generateSeasonReport(String season) {
        List<Farm> farms = farmRepository.findAll();
        List<FarmReportDTO> farmReports = new ArrayList<>();

        for (Farm farm : farms) {
            FarmReportDTO farmReport = new FarmReportDTO();
            farmReport.setFarmId(farm.getId());
            farmReport.setFarmName(farm.getName());

            List<SeasonReportDTO> seasonReports = new ArrayList<>();

            List<Field> springFields = farm.getFieldsBySeason(season);

            for (Field field : springFields) {
                SeasonReportDTO seasonReport = new SeasonReportDTO();
                seasonReport.setSeason(season);

                FieldReportDTO fieldReport = new FieldReportDTO();
                //seasonReport.setFieldId(field.getId());
                fieldReport.setCropType(field.getCropType());
                fieldReport.setExpectedProductTons(field.getExpectedProductTons());

                // Fetch actual harvested data for the field
                Harvested harvested = harvestedRepository.findByFieldIdAndSeason(field.getId(), "Spring");
                if (harvested != null) {
                    fieldReport.setActualHarvestedTons(harvested.getActualHarvestedTons());
                } else {
                    fieldReport.setActualHarvestedTons(0.0); // Or handle null case as needed
                }

                seasonReport.getFields().add(fieldReport);
                seasonReports.add(seasonReport);
            }

            farmReport.setSeasons(seasonReports);
            farmReports.add(farmReport);
        }

        return farmReports;
    }
}

