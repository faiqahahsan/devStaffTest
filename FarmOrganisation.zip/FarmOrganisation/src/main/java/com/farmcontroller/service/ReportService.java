package com.farmcontroller.service;

import com.farmcontroller.dto.FarmReportDTO;

import java.util.List;

public interface ReportService {
    List<FarmReportDTO> generateFarmReports();
    List<FarmReportDTO> generateSeasonReport(String season) ;
}