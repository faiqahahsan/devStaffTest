package com.farmcontroller.dto;

import com.farmcontroller.models.Farm;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class PlantedRequest {

    private String farmName;

    private String season;
    private double plantingAreaAcres;
    private String cropType;
    private double expectedProductTons;
}
