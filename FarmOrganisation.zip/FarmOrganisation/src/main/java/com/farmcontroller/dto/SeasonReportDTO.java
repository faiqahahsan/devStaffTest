package com.farmcontroller.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SeasonReportDTO {
    private String season;
    private double plantedAreaAcres;
    private double actualHarvestedTons;
    private List<FieldReportDTO> fields;



}