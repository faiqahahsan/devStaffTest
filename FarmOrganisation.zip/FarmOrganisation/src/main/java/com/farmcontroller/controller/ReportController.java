package com.farmcontroller.controller;

import com.farmcontroller.dto.FarmReportDTO;
import com.farmcontroller.service.ReportService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
//@Api(tags = "Report Controller")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/farms")
    public List<FarmReportDTO> getFarmReports() {
        return reportService.generateFarmReports();
    }
}
