package com.farmcontroller.controller;

import com.farmcontroller.dto.PlantedRequest;
import com.farmcontroller.models.Farm;
import com.farmcontroller.models.Field;
import com.farmcontroller.models.Harvested;
import com.farmcontroller.repository.FarmRepository;
import com.farmcontroller.repository.FieldRepository;
import com.farmcontroller.repository.HarvestedRepository;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.ArrayList;

@RestController
@RequestMapping("/api")
//@Api(tags = "Field Controller")
public class FieldController {

    @Autowired
    private FieldRepository fieldRepository;
    @Autowired
    private FarmRepository farmRepository;

    @Autowired
    private HarvestedRepository harvestedRepository;

    @PostMapping("/planted")
    public Field setPlantedInfo(@RequestBody PlantedRequest plantedRequest) {


        Farm farm =farmRepository.findFarmByName(plantedRequest.getFarmName());
        if(farm== null){
            farm = new Farm();
            farm.setName(plantedRequest.getFarmName());
            farm.setFields(new ArrayList<>());
        }
        farm = farmRepository.save(farm);

        Field field = new Field();
        field.setFarm(farm);
        field.setSeason(plantedRequest.getSeason());
        field.setCropType(plantedRequest.getCropType());
        field.setPlantingAreaAcres(plantedRequest.getPlantingAreaAcres());
        field.setExpectedProductTons(plantedRequest.getExpectedProductTons());
        field = fieldRepository.save(field);
        farm.getFields().add(field);
        farmRepository.save(farm);

        return field;
    }

    @PostMapping("/harvested")
    public Harvested storeHarvestedInfo(@RequestBody Harvested harvested) {
        return harvestedRepository.save(harvested);
    }
}