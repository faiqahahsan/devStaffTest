package com.farmcontroller.repository;


import com.farmcontroller.models.Harvested;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface HarvestedRepository extends JpaRepository<Harvested, Long> {

    @Query("SELECT h FROM Harvested h JOIN Field f ON h.fieldId = f.id WHERE h.fieldId = :fieldId AND f.season = :season")
    Harvested findByFieldIdAndSeason(@Param("fieldId") Long fieldId, @Param("season") String season);

}

