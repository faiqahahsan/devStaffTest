package com.farmcontroller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmOrganisationApplication {

    public static void main(String[] args) {
        SpringApplication.run(FarmOrganisationApplication.class, args);
    }

}
