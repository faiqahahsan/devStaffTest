package com.farmcontroller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmOrganisationApplicationTests {

    @Test
    void contextLoads() {
    }

}
